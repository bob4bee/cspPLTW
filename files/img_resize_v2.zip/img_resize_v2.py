# -*- coding: utf-8 -*-

# Imported relevant libraries
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
import matplotlib.pyplot as plt
import os.path

# Established directory with image file and opened that file as PIL
directory=os.path.dirname(os.path.abspath(__file__))
filename1=os.path.join(directory,"download.jpg")
im=Image.open(filename1)

# Used PIL Library to square the image and resize to 64x64 pixels
cropto=min(im.size[0],im.size[1])
img=im.crop((0,0,cropto,cropto))
resize=64
image_small=img.resize((resize,resize))

# Wrote on the image "8-bit"
draw=ImageDraw.Draw(image_small)
font_type=ImageFont.truetype("8-BIT WONDER.TTF",16)
draw.text((2,2),"8 bit",(0,0,0),font=font_type)
draw.rectangle([18,9,23,11],fill=(0,0,0))

# Saved the image as test.bmp file
image_small.save("test.bmp")

# Opened the test.bmp file as a PLT image for 8-bit rendering
filename2 = os.path.join(directory,"test.bmp")
img=plt.imread(filename2)
image_original=plt.imread(os.path.join(directory,"download.jpg"))

# Change the image into 8-bit
for row in range(0,resize):
    for column in range (0,resize):
        newr=int(img[row][column][0]/32)*32
        newg=int(img[row][column][1]/32)*32
        newb=int(img[row][column][2]/32)*32
        img[row][column]=[newr,newg,newb]
        
# Create figure with 2 subplots
fig, ax = plt.subplots(1,2)

# Show the image data in each subplot
ax[0].imshow(image_original, interpolation="none")
ax[1].imshow(img, interpolation="none")

#Show the figure on the screen
fig.show()